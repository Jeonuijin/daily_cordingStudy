package polymorphism01;

public class LgTV {
	public void on() {
		System.out.println("LgTV - 전원ON");
	}
	public void off() {
		System.out.println("LgTV - 전원OFF");
	}
	public void soundUp() {
		System.out.println("LgTV - 소리크게");
	}
	public void soundDown() {
		System.out.println("LgTV - 소리작게");
	}
}
