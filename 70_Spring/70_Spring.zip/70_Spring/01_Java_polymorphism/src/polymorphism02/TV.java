package polymorphism02;

public interface TV {
	public void powerOn();
	public void powerOff();
	public void VolumeUp();
	public void VolumeDown();
}
