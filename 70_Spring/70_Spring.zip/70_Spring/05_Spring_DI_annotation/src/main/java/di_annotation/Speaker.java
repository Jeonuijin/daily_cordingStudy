package di_annotation;

public interface Speaker {
	public void volumnUp();
	public void volumnDown();
}
