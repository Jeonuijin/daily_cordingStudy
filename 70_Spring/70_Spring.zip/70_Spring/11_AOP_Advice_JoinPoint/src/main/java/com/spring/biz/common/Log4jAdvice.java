package com.spring.biz.common;

public class Log4jAdvice {
	public void printLogging() {
		System.out.println("[공통로그-log4j] 비즈니스 수행전 로그");
	}
}
