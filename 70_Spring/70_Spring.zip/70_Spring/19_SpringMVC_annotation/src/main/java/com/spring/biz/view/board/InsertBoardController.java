package com.spring.biz.view.board;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spring.biz.board.BoardVO;
import com.spring.biz.board.impl.BoardDAO;

@Controller
public class InsertBoardController {
	
	@RequestMapping("/insertBoard.do")
	public String insertBoard(BoardVO vo, BoardDAO boardDAO)
			throws ServletException, IOException {
		System.out.println(">>> 게시글 입력");
		
		//1. 전달받은 데이터 추출(확인)
		//2. DB연동작업(입력) ====>  request파라미터 값을 하나하나 받을 필요없이 vo에 담긴 데이터이름과 같으면 자동으로 동일한 이름의 데이터가 담긴다.
		
		boardDAO.insertBoard(vo);
		
		return "getBoardList.do";
	}

}
