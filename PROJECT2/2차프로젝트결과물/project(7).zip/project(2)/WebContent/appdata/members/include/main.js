	function main() { // 메인
		location.href="01_main.jsp";
	}
	function login() { // 로그인
		location.href="02_login.jsp";
	}
	function signUp() { // 회원가입
		location.href="03_signUp.jsp";
	}