	function update_go() { // 정보수정
		location.href="06_myPage_update.jsp";
	}
	function delete_go() { // 회원탈퇴
		location.href="06_myPage_delete.jsp";
	}