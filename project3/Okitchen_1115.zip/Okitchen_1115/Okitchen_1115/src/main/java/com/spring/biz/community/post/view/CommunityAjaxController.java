package com.spring.biz.community.post.view;

public class CommunityAjaxController {

}
