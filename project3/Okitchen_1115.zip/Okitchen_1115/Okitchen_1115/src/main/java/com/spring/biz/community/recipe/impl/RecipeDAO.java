package com.spring.biz.community.recipe.impl;

public class RecipeDAO {

}
