package com.spring.biz.community.recipe.view;

public class RecipeAjaxController {

}
