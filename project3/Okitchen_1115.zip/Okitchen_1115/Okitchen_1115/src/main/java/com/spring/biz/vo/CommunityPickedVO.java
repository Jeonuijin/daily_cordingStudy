package com.spring.biz.vo;

public class CommunityPickedVO {
	private int commPickId;
	private int communityId;
	private String userId;
}
