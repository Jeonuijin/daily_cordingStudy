package com.spring.biz.vo;

public class PickedVO {
	private int pickId;
	private String userId;
	private int productId;
}
